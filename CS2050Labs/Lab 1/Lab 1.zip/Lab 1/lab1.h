#include <stdio.h>
#include <stdlib.h>

int avgOdd(int *array, int size, float *result);
