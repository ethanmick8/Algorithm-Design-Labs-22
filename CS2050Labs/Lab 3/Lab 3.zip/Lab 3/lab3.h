#include <stdio.h>
#include <stdlib.h>

int * createCenteredArray( int size );
int getAtIndex( int * array, int size, int index );
float averageLowerHalf( int * array, int size );
void freeCenteredArray( int * array, int size );